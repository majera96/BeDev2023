<?php

class Log
{
    public static function log($sto)
    {
        echo '<pre>';
        print_r($sto);
        echo '</pre>';
    }
}